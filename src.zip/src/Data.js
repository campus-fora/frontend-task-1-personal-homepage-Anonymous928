import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Data() {
  const [data, setData] = useState([]);
  const [id, setId] = useState('');

  const handleIdChange = (event) => {
    setId(event.target.value);
  };

  const handleDelete = (event) => {
    event.preventDefault();
    axios.delete(`http://localhost:5000/api/data/${id}`)
    .then(response => {
      console.log(response);
      setData(data.filter(item => item.id !== id));
    })
    .catch(error => {
      console.log(error);
      alert('Id not found');
    });
  };

  useEffect(() => {
    axios.get('http://localhost:5000/api/data')
    .then(response => {
      console.log(response);
      setData(response.data);
    })
    .catch(error => {
      console.log(error);
    });
  }, []);

  return (
    <div>
      {data.map(item => (
        <div key={item.id}>
          <p>{item.id}: {item.text}</p>
        </div>
      ))}
      <form onSubmit={handleDelete}>
        <div>
          <label>Id:</label>
          <input type="text" value={id} onChange={handleIdChange} />
        </div>
        <button type="submit">Delete</button>
       </form>
     </div>
   );
 }
 
 export default Data;

