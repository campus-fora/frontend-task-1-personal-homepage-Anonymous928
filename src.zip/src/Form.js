import React, { useState } from 'react';
import axios from 'axios';

function Form() {
  const [id, setId] = useState('');
  const [text, setText] = useState('');

  const handleIdChange = (event) => {
    setId(event.target.value);
  };

  const handleTextChange = (event) => {
    setText(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    axios.post('http://localhost:5000/api/data', {
      id: id,
      text: text
    })
    .then(response => {
      console.log(response);
    })
    .catch(error => {
      console.log(error);
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Id:</label>
        <input type="text" value={id} onChange={handleIdChange} />
      </div>
      <div>
        <label>Text:</label>
        <input type="text" value={text} onChange={handleTextChange} />
      </div>
      <button type="submit">Post</button>
    </form>
  );
}

export default Form;
