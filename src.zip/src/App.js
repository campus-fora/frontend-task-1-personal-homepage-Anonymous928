// import React from 'react';
// import Form from './Form';
// import Data from './Data';

// function App() {
//   return (
//     <div>
//       <Form />
//       <Data />
//     </div>
//   );
// }

// export default App;



import { useState } from 'react';

function App() {
  const [idInput, setIdInput] = useState('');
  const [textInput, setTextInput] = useState('');
  const [textList, setTextList] = useState([]);

  const handleIdInputChange = (event) => {
    setIdInput(event.target.value);
  };

  const handleTextInputChange = (event) => {
    setTextInput(event.target.value);
  };

  const handlePostClick = () => {
    const existingIndex = textList.findIndex((item) => item.id === idInput);
    if (existingIndex !== -1) {
      setTextList((prevList) => {
        const newList = [...prevList];
        newList[existingIndex].text = textInput;
        return newList;
      });
    } else {
      setTextList((prevList) => [...prevList, { id: idInput, text: textInput }]);
    }
    setIdInput('');
    setTextInput('');
  };

  const handleGetAllClick = () => {
    alert(textList.map((item) => `${item.id}: ${item.text}`).join('\n'));
  };

  const handleDeleteClick = () => {
    const existingIndex = textList.findIndex((item) => item.id === idInput);
    if (existingIndex !== -1) {
      setTextList((prevList) => {
        const newList = [...prevList];
        newList.splice(existingIndex, 1);
        return newList;
      });
    } else {
      alert(`No text with id "${idInput}" found.`);
    }
    setIdInput('');
  };

  return (
    <div>
      <div>
        <label htmlFor="id-input">ID:</label>
        <input id="id-input" type="text" value={idInput} onChange={handleIdInputChange} />
      </div>
      <div>
        <label htmlFor="text-input">Text:</label>
        <input id="text-input" type="text" value={textInput} onChange={handleTextInputChange} />
      </div>
      <div>
        <button onClick={handlePostClick}>Post</button>
      </div>
      <div>
        <button onClick={handleGetAllClick}>Get All</button>
      </div>
      <div>
        <label htmlFor="delete-input">Delete ID:</label>
        <input id="delete-input" type="text" value={idInput} onChange={handleIdInputChange} />
        <button onClick={handleDeleteClick}>Delete</button>
      </div>
    </div>
  );
}

export default App;

// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
